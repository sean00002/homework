#!/bin/bash

if [ -d $1 ]
then
    ls -l ./$1 | cat | awk '{print $9}' > variable
    cat variable | sed "s/[A-Z]/&&&/g"
else
    echo 'Not a directory' | cat  > printcap3_error.log
fi
